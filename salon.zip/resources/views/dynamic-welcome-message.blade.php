{!! $html_content !!}
